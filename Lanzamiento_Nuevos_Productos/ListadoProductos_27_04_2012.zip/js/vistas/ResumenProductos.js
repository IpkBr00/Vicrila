function ResumenProductos( options ){

	this.init = function(){
		esconderNavSP();
		this.cache();
		this.vincularEventos();
		this.suscripciones();

		app.servicios.resumen.Listado();
	},
	this.cache = function(){
		this.tituloProducto = $('#tituloProducto');
		this.descripcion = $('#descripcion');
		this.tablaElementos = $('#tablaElementos');
		
		/*this.formularioAlta = $('#formNuevoArticulo');
		this.btnAlta = $('#btnAdd');

		this.btnAlta.button();
		this.formularioAlta.dialog(
			{
				title:'Añadir producto',
				autoOpen : false,
				modal: true,
				width: 'auto',
				buttons : {
					'Guardar' : function(){ app.eventos.publicar('NuevoArticulo', {}); },
					'Cancelar' : function(){ $(this).dialog('close'); }
				}
			}
		);*/
	},
	this.vincularEventos = function(){
		var self = this;

		/*this.btnAlta.on('click', function(){
			self.formularioAlta.dialog('open');
		});*/

		this.tablaElementos.delegate(' .pasarNavision', 'click', function(){
			var idEnlace =  $(this).closest('a').attr('id');
			var tipo = idEnlace.split('-')[0];
			var idResumen = idEnlace.split('-')[1];

			alert('Iniciamos el paso a Navision, espere hasta que aparezca el resultado de la operación.');

			app.servicios.navision.PasoANavision(tipo, idResumen);
		});
	},
	this.suscripciones = function(){

		app.eventos.subscribir("modelos.dominio.resumen.Listado", $.proxy(this.Render, this));
		app.eventos.subscribir("modelos.navision.productos.PasoANavision", $.proxy(this.PostPasoANavision,this));
	},
	this.Render = function(evento, respuesta){
		var datos =JSON.parse(respuesta[0].d);
		var producto = JSON.parse(datos.Producto);
		var resumen = JSON.parse(datos.Resumen);

		this.RenderDatosLanzamiento(producto);
		$.proxy(this.RenderArticulos(resumen) ,this);
	},
	this.RenderDatosLanzamiento = function(producto){
		var titulo = producto.codigo + ' - ' + producto.denominacion;

		this.tituloProducto.text(titulo);
		this.descripcion.text(producto.descripcion);
	},
	this.RenderArticulos = function(resumen){
		if(resumen.length > 0)
		{
			var self = this;

			if($('#tablaElementos tbody tr').length > 0)
				$('#tablaElementos tbody tr').remove();
			
			$(resumen).each(function(){
				self.RenderProducto(this);
			});
		}
		else
		{
			alert('No se han obtenido resultados para el resumen del producto.');
		}
	},
	this.RenderProducto = function(producto)
	{
		producto.esNavision = false;

        if(producto.NewColumn1 != null){
        	$('th.acciones').css('width','50px');
        	producto.esNavision = true;
        }

        switch(producto.tipo)
        {
        	case "SOPORTE":
        		producto.color = 'bgGreen';
        	break;
        	case "SEMITERMINADO":
        		producto.color = 'bgMagenta';
        	break;
        	case "TERMINADO":
        		producto.color = 'bgOrange';
        	break;
        	case "EMBALAJE":
        		producto.color = 'bgBlue';
        	break;
        }

		$('#filaElementoTemplate').tmpl(producto).appendTo('#tablaElementos');
	},
	this.PostPasoANavision = function(evento, respuesta){
		var mensaje = JSON.parse(respuesta[0].d);
		
		app.log.debug('Postpaso a navision', respuesta);

		if(mensaje.Estado == 'Error')
		{
			alert(mensaje["Mensaje"] + "\n" + mensaje["Detalles Error"]);
		}
		else
		{
			alert(mensaje["Mensaje"]);	
		}
	}
};

