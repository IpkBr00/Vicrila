[
	{
		
		"part1" : "Hello",
		"part2" : "Maikel"
	}
]

