
function Articulos(options) {
	var camposSoporte = {};
	var camposSemiterminado = {};
    this.formBuilder = new FormBuilder();
    this.departamento = "";
    this.tipo = "";
    this.soportes = {};
    this.semiterminados = {};

	this.init = function () {

		$('#id_Resumen').val($.QueryString["i"]);

	    if ($.QueryString["t"].indexOf("EMBALAJE") != -1)
	        this.tipo = "EMBALAJE";
	    else
	        this.tipo = $.QueryString["t"];

	    this.cache();
	    this.vincularEventos();
	    this.suscripciones();

		app.servicios.sharepoint.GrupoUsuario();
	},
	this.cache = function () {
		$('#cambiarSoporte, #aceptarCambioSoporte, #cancelarCambioSoporte').button();
	},
	this.vincularEventos = function () {
		var self = this;
		$('#cambiarSoporte, #cancelarCambioSoporte').on('click', this.VisibilidadBaseSoporte );
		$('#cambiarSemiterminado, #cancelarCambioSemiterminado').on('click', this.VisibilidadBaseSemiterminado );

		$('#aceptarCambioSoporte').on('click',function(){
			var seleccion = $('#herenciaSoporteBloque input[type=radio]:checked');
			if(seleccion.length == 1)
			{
				$('#soporteBase').val(seleccion.val());
				$('#soporteBaseText').text(seleccion.val());
				$.proxy(self.CargarSoporteBaseEnSemiterminado(), self);

				self.VisibilidadBaseSoporte();
			}
			else
			{
				alert('Debes seleccionar un Artículo Soporte Base.');
			}
		});

		$('#aceptarCambioSemiterminado').on('click',function(){
			var seleccion = $('#herenciaSemiterminadoBloque input[type=radio]:checked');
			if(seleccion.length == 1)
			{
				$('#semiterminadoBase').val(seleccion.val());
				$('#semiterminadoBaseText').text(seleccion.val());
				$.proxy(self.CargarSemiterminadoBaseEnTerminado(), self);

				self.VisibilidadBaseSemiterminado();
			}
			else
			{
				alert('Debes seleccionar un Artículo Semiterminado Base.');
			}
		});

		$(document).delegate('table input#alto, table input#ancho,table input#longitud','change', function(){
			var resultado = 0;
			var alto = $('input#alto').val();
			var ancho = $('input#ancho').val();
			var longitud = $('input#longitud').val();

			resultado = Math.round((alto * ancho * longitud) / 1000000000); 
			$('input#volumen').val(resultado);
		});
	},
	this.suscripciones = function () {
	    $.subscribe('FormBuilder/guardar', $.proxy(this.Guardar, this));

		app.eventos.subscribir('FormBuilder/Inizializado', $.proxy(this.AplicarSeguridad, this));
		app.eventos.subscribir('FormBuilder/CargarRegistro', $.proxy(this.BuscarArticulo, this));

		app.eventos.subscribir('modelos.sharepoint.info.getGrupoUsuario', $.proxy(this.SetDepartamento, this));
	    app.eventos.subscribir('modelos.dominio.formularios.Buscar',$.proxy(this.RenderFomulario, this));
	    app.eventos.subscribir('modelos.dominio.articulos.Listado',$.proxy(this.CargarDatosHeredados , this));
		app.eventos.subscribir('modelos.dominio.articulos.Buscar', $.proxy(this.CargarRegistro, this));
	    app.eventos.subscribir('modelos.dominio.operarios.insertando', $.proxy(this.RefrescarOperario, this));
	    app.eventos.subscribir('modelos.dominio.operarios.actualizar', function(){ window.location = 'ResumenProducto.aspx'});

	    app.eventos.subscribir('UI/InsercionOperario', $.proxy(this.InsercionOperario, this));
	    app.eventos.subscribir('ActualizarArticulo', function(){ window.location = 'ResumenProducto.aspx'});
	},
	this.SetDepartamento = function(evento, respuesta){
		this.departamento = respuesta[0].d;
		this.formBuilder.departamento = respuesta[0].d;

		app.servicios.formularios.Buscar('tipo', this.tipo)
	},
	this.AplicarSeguridad = function(){
		var self = this;
		var seccion = "";

		$('.tituloSeccion').each(function(){
			seccion = $($(this).data('target')).attr('id');
			app.eventos.publicar('FormBuilder/DeshabilitarSeccion', seccion);
		});
	},
	this.RenderFomulario = function (evento, respuesta){
		var formulario = JSON.parse(respuesta[0].d);
        var esquema = JSON.parse(formulario.esquema);
        var operarios = JSON.parse(formulario.operarios);

		this.formBuilder.suscripciones();
        app.eventos.publicar("FormBuilder/Inicializar", [formulario, esquema, $.QueryString["i"]]);
	},
	this.BuscarArticulo = function(){
		var tipo = "";

		$('#id_Resumen').val($.QueryString["i"]);

	    if ($.QueryString["t"].indexOf("EMBALAJE") != -1)
	        tipo = "EMBALAJE";
	    else
	        tipo = $.QueryString["t"];

		app.servicios.articulos.Buscar(tipo, 'id_Resumen', $.QueryString["i"]);
	},
	this.CargarRegistro = function(evento, respuesta){		

		var datos = JSON.parse(respuesta[1][0].d);
		app.log.debug('Datos ' , datos);

		$.each(datos, function(k,v){
			if( !(v == '' || v == null) )
			{

				if( $('#' + k).attr('type')  == 'checkbox' ) 
				{
					if(v == 'SI')
						$('#' + k).attr('checked',  'checked');
					else
						$('#' + k).attr('checked');
				}
				else
					$('#' + k).val(v);
				
			}
		});

		if(this.tipo == 'SEMITERMINADO')
	    {
	    	$('#soporteBase').val(datos["soporteBase"]);
	    	app.servicios.articulos.Listado('SOPORTE');	
	    }
	    else if(this.tipo == 'TERMINADO'){
	    	$('#soporteBase').val(datos["soporteBase"]);
	    	$('#semiterminadoBase').val(datos["semiterminadoBase"]);
	    	app.servicios.articulos.Listado('SOPORTE');	
	    	app.servicios.articulos.Listado('SEMITERMINADO');	
	    }

	    if($.QueryString["N"] == 'true')
	    {
	    	$('input').each(function(){ $(this).attr('disabled', true)});
			$('select').each(function(){ $(this).attr('disabled', true)});
			$('#btnCancelar').attr('disabled', false);

	    }

		if($('#codigo5Digitos').length == 1)
		{
			var codigoOriginal = $('#codigo').val();
			if( codigoOriginal != '' && codigoOriginal.length >= 5)
			{
				$('#codigo5Digitos').val(codigoOriginal.substring(0,5));
			}
			
		}

		$('#infoTipo').text(this.tipo);
		$('#infoCodigo').text(datos.codigo);
		$('#infoDescripcion').text(datos.descripcion);

		
		app.eventos.publicar('FormBuilder/HabilitarSeccion', this.departamento);

	},
	this.Guardar = function(){
		var parametros;
		var output;

		if(this.departamento == 'Produccion' )
		{
			output = inputToJson('#'+ this.departamento + ' #tablaSeccion');
			parametros =  JSON.stringify({Registro: this.formBuilder.operarios });	
			//app.servicios.operarios.Actualizar(parametros);
		}
		else
			output = inputToJson('#'+ this.departamento);

		//var output = inputToJson('#'+ this.departamento);
		output["id_Resumen"] = $('#id_Resumen').val();
		if(this.tipo == 'SEMITERMINADO')
	    {
	    	output["soporteBase"] = $('#soporteBase').val()
	    }
	    else if(this.tipo == 'TERMINADO'){
	    	output["soporteBase"] = $('#soporteBase').val()
	    	output["semiterminadoBase"] = $('#semiterminadoBase').val()
	    }

		this.departamento = this.departamento.replace(this.departamento[0] , this.departamento[0].toLowerCase());
		if(this.departamento == 'desarrolloProducto')
			this.departamento = 'desarrollo';

		if(this.departamento == 'produccion2' )
		{
			parametros =  JSON.stringify({Registro: this.formBuilder.operarios });	
			app.servicios.operarios.Actualizar(parametros);
		}
		else
		{
			app.log.debug('Seccion a guardar', output);
			parametros =  JSON.stringify({Tipo: $.QueryString["t"], Departamento: this.departamento , Registro: output });	
			$.ajax({
			    type: "POST",
			    contentType: "application/json; charset=utf-8",
				url:'Ajax.aspx/ActualizarArticulo',
				dataType: 'text',
				data : parametros,
				success: function(data, textStatus, jqXHR){
					alert('El artículo se ha guardado con exito.');
					app.eventos.publicar('ActualizarArticulo',[]);
				},
				error: function(jqXHR, textStatus, errorThrown){
					alert( '*** Error *** \n Metodo: Insertar \n Mensaje: ' +  errorThrown );
				},
				complete: function(){}
			});
		}
	},
	this.LimpiarFormulario = function () {
	    $('#formulario input[type=hidden]').each(function () { $(this).val(''); });
	    $('#formulario input[type=text]').each(function () { $(this).val(''); });
	    $('#formulario input[type=checkbox]').each(function () { $(this).attr('checked', false); });
	    $('#formulario textarea').each(function () { $(this).val(''); });
	},
	this.InsercionOperario = function(evento, respuesta){
		var operario = JSON.stringify({Registro: respuesta[0]});
		app.servicios.operarios.Insertar(operario);
	},
	this.RefrescarOperario = function(evento, respuesta){
		var datos = JSON.parse(respuesta[0].d);

		$(frm.formBuilder.operarios).each(function(){
			if(this.NumeroLinea == datos.NumeroLinea)
			{
				this.Id = datos.ID;
			}
		})
	},
	this.RenderSoportesBase = function(datos){


		$('#templateBaseSoporte').tmpl(datos).appendTo('#basesSoporte tbody');
	},
	this.RenderSemiterminadosBase = function(datos){


		$('#templateBaseSemiterminado').tmpl(datos).appendTo('#basesSemiterminado tbody');
	},
	this.InicailizarSoportesBase = function(){
		var self = this;
		var seleccion = $('#soporteBase').val();
		if(seleccion == '')
		{
			$('#soporteBaseText').text('< NO SELECCIONADO >');
			$('#cambiarSoporte').click();
			alert('Debe seleccionar un articulo soporte para extraer los datos necesarios.')
		}
		else
		{
			$('#'+seleccion).attr('checked','checked');
			$('#soporteBaseText').text(seleccion);
		}

		var indice = 0;
		var valido = true;

		$(this.soportes).each(function(){

			$(camposSoporte[self.departamento]).each(function(k,v){
				valido = valido && (self.soportes[indice][this.origen] != null);
			});
			
			self.soportes[indice].esValido = valido;

			if(!valido)
				$('#' + this.codigo).attr('disabled','disabled');

			indice++;
		});

	},
	this.IniacilizarSemiterminadosBase = function(){
		var self = this;
		var seleccion = $('#semiterminadoBase').val();
		if(seleccion == '')
		{
			$('#semiterminadoBaseText').text('< NO SELECCIONADO >');
			$('#cambiarSemiterminado').click();
			alert('Debe seleccionar un articulo semiterminado para extraer los datos necesarios.')
		}
		else
		{
			$('#'+seleccion).attr('checked','checked');
			$('#semiterminadoBaseText').text(seleccion);
		}

		var indice = 0;
		var valido = true;

		$(this.semiterminados).each(function(){

			$(camposSemiterminado[self.departamento]).each(function(k,v){
				valido = valido && (self.semiterminados[indice][this.origen] != null);
			});
			
			self.semiterminados[indice].esValido = valido;

			if(!valido)
				$('#' + this.codigo).attr('disabled','disabled');

			indice++;
		});

	},
	this.CargarSoporteBaseEnSemiterminado =function(){
		var self = this;
		var codigo = $('#soporteBase').val();
		var soporteSeleccionado;

		if(codigo != '')
		{
			$(this.soportes).each(function(){
				if(this.codigo == codigo )
					soporteSeleccionado = this;
			});

			var valorActual = '';
			var valorSoporte = '';

			$(camposSoporte[self.departamento]).each(function(k,v){
				valorActual = $('#' + this.destino).val();
				valorSoporte = soporteSeleccionado[this.origen];
			
				if(valorActual == '' || valorActual == null || valorActual == '0')
				{
					if(valorSoporte != '' || valorSoporte != null)
					{
						 $('#'+ this.destino).val(valorSoporte);
					}
				}
			});
		}
	},
	this.CargarSemiterminadoBaseEnTerminado = function(){
		var self = this;
		var codigo = $('#semiterminadoBase').val();
		var semiterminadoSeleccionado;

		if(codigo != '')
		{
			$(this.semiterminados).each(function(){
				if(this.codigo == codigo )
					semiterminadoSeleccionado = this;
			});

			var valorActual = '';
			var valorSemiterminado = '';

			$(camposSemiterminado[self.departamento]).each(function(k,v){
				valorActual = $('#' + this.destino).val();
				valorSemiterminado = semiterminadoSeleccionado[this.origen];

				if(valorActual == '' || valorActual == null || valorActual == '0')
				{
					if(valorSemiterminado != '' || valorSemiterminado != null)
					{
						 $('#'+ this.destino).val(valorSemiterminado);
					}
				}
			});
		}
	},
	this.CamposSoporteASemiterminado = function(){
		camposSoporte = {};
		camposSoporte.DesarrolloProducto = [];
		camposSoporte.DesarrolloProducto.push({destino:"claseVidrio", origen:"claseVidrio"});
		camposSoporte.DesarrolloProducto.push({destino:"tratamientoTermico", origen:"tratamientoTermico"});
		camposSoporte.DesarrolloProducto.push({destino:"fdf", origen:"fdf"});
		camposSoporte.DesarrolloProducto.push({destino:"pesoNetoArticulo", origen:"pesoNeto"});

		camposSoporte.Produccion = [];
		camposSoporte.Produccion.push({destino: "cadenciaEstandar", origen:"cadenciaEstandar"});
		camposSoporte.Produccion.push({destino: "rendimientoEstandar", origen:"rendimientoEstandar"});
	},
	this.CamposSoporteATerminado = function(){
		camposSoporte = {};
		camposSoporte.DesarrolloProducto = [];
		camposSoporte.DesarrolloProducto.push({destino:"fdf", origen:"fdf"});
		camposSoporte.DesarrolloProducto.push({destino:"pesoNetoUnidadVenta", origen:"pesoNeto"});

		camposSoporte.Produccion = [];
		camposSoporte.Produccion.push({destino: "cadenciaEstandar", origen:"cadenciaEstandar"});
		camposSoporte.Produccion.push({destino: "rendimientoEstandar", origen:"rendimientoEstandar"});
	},
	this.CamposSemiterminadoATerminado = function(){
		camposSemiterminado = {};
		camposSemiterminado.DesarrolloProducto = [];
		camposSemiterminado.DesarrolloProducto.push({destino:"decorado", origen:"decorado"});
		camposSemiterminado.DesarrolloProducto.push({destino:"serie", origen:"serie"});
	},
	this.CargarDatosHeredados = function(evento, respuesta){
		var articulo = JSON.parse(respuesta[1][0].d);
		var departamento = this.departamento;
		var valido = true;

		if(this.tipo == 'SEMITERMINADO')
		{		
			if(respuesta[0] == 'SOPORTE')
			{
				
				this.soportes = articulo;
				this.CamposSoporteASemiterminado();

				if(camposSoporte[this.departamento] != undefined)
				{
					$('#herenciaSoporte').removeClass('noDisplay');
					this.RenderSoportesBase(articulo);
					$.proxy( this.InicailizarSoportesBase(),this );
					$.proxy( this.CargarSoporteBaseEnSemiterminado(), this);
				}
			}

			$('#pesoBrutoArticulo, #pesoNetoArticulo, #unidadVentaPalet').change(
					function(){
						var pesoBrutoArticulo = parseFloat($('#pesoBrutoArticulo').val());
						var pesoNetoArticulo = parseFloat($('#pesoNetoArticulo').val());
						var unidadVentaPalet = parseFloat($('#unidadVentaPalet').val());
						$('#pesoBrutoPalet').val(pesoBrutoArticulo * unidadVentaPalet);
						$('#pesoNetoPalet').val(pesoNetoArticulo * unidadVentaPalet);
					}
			);
		}
		else if(this.tipo == 'TERMINADO')
		{
			if(respuesta[0] == 'SOPORTE')
			{
				this.soportes = articulo;
				this.CamposSoporteATerminado();

				if(camposSoporte[this.departamento] != undefined)
				{
					$('#herenciaSoporte').removeClass('noDisplay');
					this.RenderSoportesBase(articulo);
					$.proxy( this.InicailizarSoportesBase(),this );
					$.proxy( this.CargarSoporteBaseEnSemiterminado(), this);
				}
			}
			else if(respuesta[0] == 'SEMITERMINADO')
			{
				this.semiterminados = articulo;
				this.CamposSemiterminadoATerminado();

				if(camposSemiterminado[this.departamento] != undefined)
				{
					$('#herenciaSemiterminado').removeClass('noDisplay');
					this.RenderSemiterminadosBase(articulo);
					$.proxy( this.IniacilizarSemiterminadosBase(),this );
					$.proxy( this.CargarSemiterminadoBaseEnTerminado(), this);
				}
				
			}

			$('#pesoBrutoUnidadVenta, #pesoNetoUnidadVenta, #unidadesVentaPalet, #unidadesDeVenta').change(
				function(){
					var pesoBrutoUnidadVenta = parseFloat($('#pesoBrutoUnidadVenta').val());
					var pesoNetoUnidadVenta = parseFloat($('#pesoNetoUnidadVenta').val());
					var unidadesVentaPalet = parseFloat($('#unidadesVentaPalet').val());
					var unidadesDeVenta = parseFloat($('#unidadesDeVenta').val());
					$('#pesoBrutoPalet').val(pesoBrutoUnidadVenta * unidadesVentaPalet);
					$('#pesoNetoPalet').val(pesoNetoUnidadVenta * unidadesVentaPalet);
				}
			);
		}
	},
	this.VisibilidadBaseSoporte = function(){
		$('#cambiarSoporte, #aceptarCambioSoporte, #cancelarCambioSoporte').toggle();
		$('#herenciaSoporteBloque').toggleClass('noDisplay');
	},
	this.VisibilidadBaseSemiterminado = function(){
		$('#cambiarSemiterminado, #aceptarCambioSemiterminado, #cancelarCambioSemiterminado').toggle();
		$('#herenciaSemiterminadoBloque').toggleClass('noDisplay');
	}
};



