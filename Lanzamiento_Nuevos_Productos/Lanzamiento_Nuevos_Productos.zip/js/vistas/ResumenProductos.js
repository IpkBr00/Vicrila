function ResumenProductos( options ){

	this.init = function(){
		esconderNavSP();
		this.cache();
		this.vincularEventos();
		this.suscripciones();

		app.servicios.resumen.Listado();
	},
	this.cache = function(){
		this.tituloProducto = $('#tituloProducto');
		this.descripcion = $('#descripcion');
		this.tablaElementos = $('#tablaElementos');
	},
	this.vincularEventos = function(){
		var self = this;

		this.tablaElementos.delegate(' .pasarNavision', 'click', function(){
			var idEnlace =  $(this).closest('a').attr('id');
			var tipo = idEnlace.split('-')[0];
			var idResumen = idEnlace.split('-')[1];

			alert('Iniciamos el paso a Navision, espere hasta que aparezca el resultado de la operación.');

			app.servicios.navision.PasoANavision(tipo, idResumen);
		});
	},
	this.suscripciones = function(){
		app.eventos.subscribir("modelos.dominio.resumen.Listado", $.proxy(this.Render, this));
		app.eventos.subscribir("modelos.navision.productos.PasoANavision", $.proxy(this.PostPasoANavision,this));
	},
	this.Render = function(evento, respuesta){
		var datos =JSON.parse(respuesta[0].d);
		var producto = JSON.parse(datos.Producto);
		var resumen = JSON.parse(datos.Resumen);

		this.RenderProducto(producto);
		this.RenderArticulos(resumen);
	},
	this.RenderProducto = function(producto){
		var titulo = producto.codigo + ' - ' + producto.denominacion;

		this.tituloProducto.text(titulo);
		this.descripcion.text(producto.descripcion);
	}
	this.RenderArticulos = function(resumen){
		if(resumen.length > 0)
		{
			if($('#tablaElementos tbody tr').length > 0)
				$('#tablaElementos tbody tr').remove();
			
			$(resumen).each(function(){
				this.esNavision = false;

	            if((this.desarrollo == "completado" || this.desarrollo  == "noParticipa") &&
	               (this.compras == "completado" || this.compras  == "noParticipa") &&
	               (this.supplyChain == "completado" || this.supplyChain  == "noParticipa") && 
	               (this.comercial == "completado" || this.comercial  == "noParticipa") &&
	               (this.almacen == "completado" || this.almacen  == "noParticipa") &&
	               (this.finanzas == "completado" || this.finanzas  == "noParticipa") && 
	               (this.produccion == "completado" || this.produccion  == "noParticipa"))
	            {
	            	
	            	this.finalizado = true
	            }

	            if(this.NewColumn1 != null){
	            	$('th.acciones').css('width','50px');
	            	this.esNavision = true;
	            	this.finalizado = false;
	            }

	            switch(this.tipo)
	            {
	            	case "SOPORTE":
	            		this.color = 'bgGreen';
	            	break;
	            	case "SEMITERMINADO":
	            		this.color = 'bgMagenta';
	            	break;
	            	case "TERMINADO":
	            		this.color = 'bgOrange';
	            	break;
	            	case "EMBALAJE":
	            		this.color = 'bgBlue';
	            	break;
	            }

			});

			$.ajax({
		    	type: "POST",
		    	contentType: "application/json; charset=utf-8",
		    	url: 'Ajax.aspx/GrupoActual',
		    	dataType: 'json',
		    	success: function (data, textStatus, jqXHR) {
		        	if( data.d  != 'Produccion')
		        	{	
		        		$('.pasarNavision').each(function(){
		        			$(this).hide();
	        			})
		        	}
		    },
		    error: function (jqXHR, textStatus, errorThrown) {
		        alert('*** Error *** \n Metodo: Listado \n Mensaje: ' + errorThrown);
		    },
		    complete: function () { }
	   		});

			$('#filaElementoTemplate').tmpl(resumen).appendTo('#tablaElementos');
		}
		else
		{
			alert('No se han obtenido resultados para el resumen del producto.');
		}
	},
	this.PostPasoANavision = function(evento, respuesta){
		var mensaje = JSON.parse(respuesta[0].d);
		
		app.log.debug('Postpaso a navision', respuesta);

		if(mensaje.Estado == 'Error')
		{
			alert(mensaje["Mensaje"] + "\n" + mensaje["Detalles Error"]);
		}
		else
		{
			alert(mensaje["Mensaje"]);	
		}
	}
};

